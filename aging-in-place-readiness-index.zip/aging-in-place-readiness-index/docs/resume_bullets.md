# Resume-ready section

Drop these directly into your resume under a **"Projects"** or
**"Selected Projects"** heading. Copy the variant that matches how the
rest of your resume reads. Swap the exact percentage / count for your
real numbers once you rerun on live data.

---

## Short, punchy (good for 1-page resumes)

**Aging-in-Place Readiness Index — Personal Portfolio Project · April 2026**
[GitHub ↗](https://github.com/221810306002/aging-in-place-readiness-index) · [Live dashboard ↗](https://aishwaryasharma2615.github.io/aging-in-place-readiness-index/)

- Built a county-level composite index (0–100) scoring whether U.S. seniors can reasonably live independently, combining 7 public data domains (clinical supply, social infrastructure, economic security, physical safety, digital access, food security, caregiver proximity).
- Designed a star schema in SQL and an ETL template for U.S. Census ACS, HRSA AHRF, CMS, USDA, and IRS migration data; pipeline runs end-to-end in < 10 seconds.
- Identified 4 interpretable county archetypes via K-means clustering and ranked intervention levers with a logistic regression (99 % training accuracy); translated model coefficients into plain-English policy recommendations.
- Published an interactive Plotly dashboard and a one-page executive brief for state Medicaid directors.

---

## Longer, achievement-first (good for 2-page resumes or LinkedIn)

**Aging-in-Place Readiness Index** — *Independent data analytics project · April 2026*

Built, documented, and shipped a socially-motivated data portfolio project in a single weekend.

- **Problem framing.** Scoped the project from a real-world question ("as adult children move away, which U.S. counties are becoming unsafe for their parents to live alone?") into a quantifiable index using only free public data.
- **Data modeling.** Designed a star schema (1 fact, 3 dimensions) in Postgres with four analytical views supporting national maps, state rollups, archetype profiles, and a county-level intervention worksheet.
- **Scoring engine.** Implemented a transparent weighted composite (AIPR Index 0–100) in Python with domain sub-scores, tier bucketing, and min-max normalization; weights are version-controlled and editable.
- **Machine learning.** K-means clustering (k=4) on the seven sub-scores surfaced interpretable county archetypes; logistic regression on standardized sub-scores quantified which domains most predict a county falling into the "Critical" tier (clinical access: odds ratio 0.05).
- **Communication layer.** Shipped an interactive Plotly HTML dashboard (hosted on GitHub Pages), Tableau and Power BI build guides, and a one-page executive brief written for state Medicaid audiences.
- **Engineering hygiene.** End-to-end reproducibility with a single `pip install -r requirements.txt`; repository includes MIT license, `.gitignore`, documented ingest template for real data sources, and a synthetic dataset for immediate demo.

**Stack:** Python · pandas · scikit-learn · Plotly · SQL · Tableau · Power BI · Git/GitHub Pages

---

## LinkedIn "Featured" blurb (150 characters)

Built a county-level Aging-in-Place Readiness Index combining 7 public-data domains into a 0–100 score — with an interactive dashboard and policy brief.

---

## Interview one-liner (memorize this)

> "I noticed that even though most older Americans want to age at home, whether they actually can depends a lot on their ZIP code — so I built a county-level readiness index that combines clinical supply, caregiver distance, and five other domains into a single score, and I used K-means clustering to find four county archetypes that each need a different intervention. It's on GitHub with an interactive dashboard — happy to walk through it."

---

## When you update your LinkedIn

1. Add the project under **Projects**, link the GitHub and the live dashboard.
2. Post a 2-paragraph LinkedIn status on the day you ship it. First paragraph = the human story (an aging parent, an adult child far away, why the numbers matter). Second paragraph = what you built. End with the dashboard link.
3. Pin the post. Recruiters scroll.
