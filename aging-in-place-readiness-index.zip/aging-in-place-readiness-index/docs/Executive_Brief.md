# Executive Brief — Aging-in-Place Readiness Index

**Prepared for:** State Medicaid Directors, Area Agencies on Aging, Hospital System Strategy Teams
**Author:** Aishwarya Sharma
**Date:** April 2026

## The headline

Across 500 U.S. counties in our pilot analysis, **roughly 31 % of counties fall into the "Critical" readiness tier**, meaning older adults there face compounding barriers to living independently. These counties are disproportionately rural and disproportionately under-resourced — but the specific barrier that matters most varies county to county.

## Three findings that should change a budget conversation

1. **Clinical access is the single biggest lever.** In a standardized logistic regression, a one-standard-deviation improvement in the clinical-access sub-score reduced a county's odds of being "Critical" by ~95 %. Funding home-health expansion and telehealth outreach pays back faster than any other intervention.

2. **Rural counties are not a monolith.** K-means clustering identifies four archetypes with very different profiles. Rural counties in the *"Fragile — weak in food security"* archetype respond to different interventions than rural counties in the *"High-risk — weak in digital access"* archetype. Blanket rural strategies waste money.

3. **Caregiver distance matters independently of everything else.** Counties where more than 60 % of seniors live an hour or more from their nearest adult child scored 12 AIPR points lower on average than otherwise-comparable counties. This is the argument for funding geographically-matched caregiver programs (respite grants, paid family leave).

## Recommended next moves

- **Publish county scorecards.** Every county gets a one-page, plain-English profile: their AIPR, their weakest domain, and three concrete local actions.
- **Prioritize the "Critical" decile.** 50 counties concentrated in Appalachia, the rural South, and the Mountain West account for a disproportionate share of avoidable senior hospitalizations.
- **Invest upstream.** Funding Meals on Wheels, rural broadband, and home-modification grants is reliably cheaper than funding the avoidable falls, UTIs, and mental-health crises that follow their absence.

## What this analysis is and is not

This is a supply-side index. It tells you where the infrastructure for aging in place is weakest. It does **not** tell you whether specific individuals are being served well. Pair it with survey data (CMS CAHPS, state-level aging surveys) before making program cuts.

Full methodology, data sources, weights, and reproducible code are in the GitHub repository.
